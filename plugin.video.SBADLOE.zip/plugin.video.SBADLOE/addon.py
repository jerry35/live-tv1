import sys
import os
import urllib
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import logging
from operator import itemgetter

def show_tags():
  tag_handle = int(sys.argv[1])
  xbmcplugin.setContent(tag_handle, 'tags')

  for tag in tags:
    iconPath = os.path.join(home, 'logos', tag['icon'])
    li = xbmcgui.ListItem(tag['name'], iconImage=iconPath)
    url = sys.argv[0] + '?tag=' + str(tag['id'])
    xbmcplugin.addDirectoryItem(handle=tag_handle, url=url, listitem=li, isFolder=True)

  xbmcplugin.endOfDirectory(tag_handle)


def show_streams(tag):
  stream_handle = int(sys.argv[1])
  xbmcplugin.setContent(stream_handle, 'streams')
  logging.warning('TAG show_streams!!!! %s', tag)
  for stream in streams[str(tag)]:
    logging.debug('STREAM HERE!!! %s', stream['name'])
    iconPath = os.path.join(home, 'logos', stream['icon'])
    li = xbmcgui.ListItem(stream['name'], iconImage=iconPath)
    xbmcplugin.addDirectoryItem(handle=stream_handle, url=stream['url'], listitem=li)

  xbmcplugin.endOfDirectory(stream_handle)


def get_params():
  """
  Retrieves the current existing parameters from XBMC.
  """
  param = []
  paramstring = sys.argv[2]
  if len(paramstring) >= 2:
    params = sys.argv[2]
    cleanedparams = params.replace('?', '')
    if params[len(params) - 1] == '/':
      params = params[0:len(params) - 2]
    pairsofparams = cleanedparams.split('&')
    param = {}
    for i in range(len(pairsofparams)):
      splitparams = {}
      splitparams = pairsofparams[i].split('=')
      if (len(splitparams)) == 2:
        param[splitparams[0]] = splitparams[1]
  return param


def lower_getter(field):
  def _getter(obj):
    return obj[field].lower()

  return _getter


addon = xbmcaddon.Addon()
home = xbmc.translatePath(addon.getAddonInfo('path'))

tags = [
  {
    'name': 'Live TV',
    'id': 'LiveTV',
    'icon': 'livetv.png'
  }, {
    'name': 'Movies',
    'id': 'Movies',
    'icon': 'movies.png'
  }
]


LiveTV = [{
 'name': 'Channel 4  (HD)',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/HDCH4/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Sky Atlantic',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/SkyAtl/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Comedy Xtra',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/CmdyXtr/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'CBS Reality',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman02.ignorelist.com:8081/CBSReality/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Cartoon Network UK',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/CARUK/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'RTE One',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/RTE1/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'RTE Two [HD]',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman02.ignorelist.com:8081/RTE2/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'BBC 1 HD',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/HDBBC1/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'BBC Two [HD]',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/HDBBC2/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'ITV',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman02.ignorelist.com:8081/ITV1/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'ITV 3',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman02.ignorelist.com:8081/ITV3/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'ITV 4',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/ITV4/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': '3e',
  'url': 'http://iptvapi.com/m3u8.php?url=http://148.253.188.6:8081/3e/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'TV3 IE',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/TV3IRL/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Sky 1',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/Sky1/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Sky 2',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/Sky2/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'TCM +1 UK',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/TCMUK/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'RTEjr',
  'url': 'http://iptvapi.com/m3u8.php?url=http://148.253.188.6:8081/RTEJR/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'DisneyJunior',
  'url': 'http://iptvapi.com/m3u8.php?url=http://148.253.188.6:8081/DIJR/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'DisneyChnl',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/Disney/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Boomerang',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/BOO/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Nick JR/VH1',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/NICKJR/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'MTV Hits',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/MTVH/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'MTV MUSIC',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/MTVM/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'MTV Dance',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman02.ignorelist.com:8081/MTVD/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'MTV BASE',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/MTVB/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'MTV ROCKS',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/MTVR/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Viva',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman02.ignorelist.com:8081/VIVA/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Discovery History',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman02.ignorelist.com:8081/DISHist/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'ID UK',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman02.ignorelist.com:8081/IDUK/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Travel Channel+1 UK',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/TRAUK/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Discovery1',
  'url': 'http://iptvapi.com/m3u8.php?url=http://148.253.188.6:8081/DIS1/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Discovery Turbo',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/DISTurbo/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Discovery Science',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/DISS/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Animal Planet uk',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/ANIUK/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Sky Greats Movies',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman02.ignorelist.com:8081/SkyGreats/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Sky Movies Select',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/SkySelect/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Sky Premiere Movies',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/SkyPremiere/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Sky Action Movies',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/SkyAction/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Sky Comedy Movies',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman02.ignorelist.com:8081/SkyComedy/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Sky ScFiHorror Movies',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman02.ignorelist.com:8081/SkySci/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Sky Family Movies',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman02.ignorelist.com:8081/SkyFamily/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Sky Movies Disney',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman02.ignorelist.com:8081/SkyDisney/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Sky DramaRom Movies',
  'url': 'http://iptvapi.com/m3u8.php?url=http://148.253.188.6:8081/SkyDrama/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'mov4men1',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/M4M/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Viasat Golf',
  'url': 'http://iptvapi.com/m3u8.php?url=http://ahman01.ignorelist.com:8081/VSGOLF/index.m3u8?token=PR8Ci1-s7Qt6cmPdxYlbTw',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': '(UK) SONY SAB',
  'url': 'http://46.249.55.237:4545/play/a06f',
  'icon': 'Vevo Tv.png',
  'disabled': False
  
}, {
  'name': 'National Geographic',
  'url': '',
  'icon': 'National Geographic.png',
  'disabled': True
}, {
  'name': 'Food Network',
  'url': '',
  'icon': 'Food Network.png',
  'disabled': True
}, {
  'name': 'FX',
  'url': '',
  'icon': 'FX.png',
  'disabled': True
}]


Movies = [{
  'name': 'Despicable Me 2',
  'url': '',
  'icon': 'Despicable Me 2.png',
  'disabled': True
}]


streams = {
  'LiveTV': sorted((i for i in LiveTV if not i.get('disabled', False)), key=lower_getter('name')),
  'Movies': sorted((i for i in Movies if not i.get('disabled', False)), key=lower_getter('name')),
  # 'LiveTV': sorted(LiveTV, key=lower_getter('name')),
  # 'Movies': sorted(Movies, key=lower_getter('name')),
}

PARAMS = get_params()
TAG = None
logging.warning('PARAMS!!!! %s', PARAMS)

try:
  TAG = PARAMS['tag']
except:
  pass

logging.warning('ARGS!!!! sys.argv %s', sys.argv)

if TAG == None:
  show_tags()
else:
  show_streams(TAG)
